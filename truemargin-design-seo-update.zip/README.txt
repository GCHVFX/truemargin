TrueMargin – Design + SEO Update

Files included:
- components/CalculatorPage.tsx

What changed:
- Results card has stronger visual hierarchy (shadow + sticky on desktop).
- Margin health tiers have clearer colour separation (4 tiers + badge + labels).
- CTA button text shortened and varies by variant.
- On-page SEO section (includes/how-to/FAQ) is now variant-specific and matches the route focus better.
- Removed duplicate FAQ JSON-LD injection (kept the main structured data script).

Install:
1) Replace your existing file at: components/CalculatorPage.tsx
2) Commit + push to GitHub
3) Vercel will auto-redeploy on push (Production if it's your main branch).
